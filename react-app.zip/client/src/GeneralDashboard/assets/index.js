import robot from "./robot.png";
import discount from "./Discount.svg";
import bill from "./bill.png";
import appstore from "./appstore.svg";
import playstore from "./playstore.svg";
import card from "./card.png";
import person1 from "./person1.jpg";
import person2 from "./person2.jpg";
import person3 from "./person3.jpg";

export {
  robot,
  discount,
  bill,
  appstore,
  playstore,
  card,
  person1,
  person2,
  person3,
};
